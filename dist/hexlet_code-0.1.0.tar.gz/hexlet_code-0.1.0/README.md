### Hexlet tests and linter status:
[![Actions Status](https://github.com/botsiti/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-50/actions)
[![Github Actions Status](https://github.com/botsiti/python-project-50/workflows/Python%20CI/badge.svg)](https://github.com/botsiti/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/db57d04c59333b824254/maintainability)](https://codeclimate.com/github/botsiti/python-project-50/maintainability)
### Work example
[![asciicast](https://asciinema.org/a/WvhjeKfKQW8VWSvY6uRLiL08Q.svg)](https://asciinema.org/a/WvhjeKfKQW8VWSvY6uRLiL08Q)