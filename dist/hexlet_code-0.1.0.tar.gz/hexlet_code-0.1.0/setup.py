# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=6.0.0,<7.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.engine_gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/botsiti/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-50/actions)\n[![Github Actions Status](https://github.com/botsiti/python-project-50/workflows/Python%20CI/badge.svg)](https://github.com/botsiti/python-project-50/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/db57d04c59333b824254/maintainability)](https://codeclimate.com/github/botsiti/python-project-50/maintainability)\n### Work example\n[![asciicast](https://asciinema.org/a/QwCknbDhhvXRAOMVy0Ots3XY2.svg)](https://asciinema.org/a/QwCknbDhhvXRAOMVy0Ots3XY2)',
    'author': 'batraz',
    'author_email': 'batrazbotsiev@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
